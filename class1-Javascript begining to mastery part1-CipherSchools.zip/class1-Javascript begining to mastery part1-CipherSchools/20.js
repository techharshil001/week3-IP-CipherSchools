// while loop 

// 0 se 9 
// dry don't repeat yourself
let i = 0; // 1 2 3 4

while(i<=9){
    console.log(i);
    i++;
}
console.log(`current value of i is ${i}`);
console.log("hello");